package esirem.com.lakaftnumrique.Authentification;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import esirem.com.lakaftnumrique.R;

public class ClientSignin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_client_signin );
    }
}
