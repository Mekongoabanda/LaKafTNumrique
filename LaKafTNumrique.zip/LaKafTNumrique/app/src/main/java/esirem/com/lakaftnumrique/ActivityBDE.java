package esirem.com.lakaftnumrique;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

import esirem.com.lakaftnumrique.Authentification.LauncherActivity;

public class ActivityBDE extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private Button btnLogout;
    private Dialog dialog;
    private ProgressDialog progressdialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_bde );

        btnLogout = findViewById( R.id.btn_logout );
         mAuth = FirebaseAuth.getInstance();

        //pour notre progressDialog déclarée là haut
        progressdialog = new ProgressDialog(this);

        btnLogout.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //si la déconnexion est ok
                //nous aurons d'abord une apparition d'une barre de progression
                progressdialog.setMessage("Déconnexion  en cours...");
                progressdialog.show();
                mAuth.signOut();
                        //Déconnexion pour pour nos providers---------------------------------------------------DEBUT
                        AuthUI.getInstance()
                                .signOut( ActivityBDE.this ).addOnCompleteListener( new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                progressdialog.hide();
                                startActivity(new Intent(ActivityBDE.this, LauncherActivity.class));
                                progressdialog.setMessage("Vous êtes déconnectés");
                                progressdialog.show();
                                finish();

                    }
                } ).addOnFailureListener( new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                } );

            }
        } );


    }
}
