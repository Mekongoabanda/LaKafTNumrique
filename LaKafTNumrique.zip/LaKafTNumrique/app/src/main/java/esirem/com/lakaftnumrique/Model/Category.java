package esirem.com.lakaftnumrique.Model;

//MenuViewHolder.class, Home.class, Category.class, menu_item.xml, home.xml, activity_home_drawer.xml, activity_home.xml
// app_bar_home.xml, content_home.xml, nav_header_home.xml

public class Category {

    private String Name;
    private String Image;

    public Category(){

    }

    public Category(String name, String image) {
        Name = name;
        Image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }
}
